
package org.sf.feeling.swt.win32.extension.jna.datatype.win32;

import org.sf.feeling.swt.win32.extension.jna.datatype.AbstractBasicData;

public abstract class Structure extends AbstractBasicData
{

	protected Structure( )
	{
		super( null );
	}

	protected Structure( Object value )
	{
		super( value );
	}
}
