package org.sf.feeling.swt.win32.extension.jna.datatype.win32;


public class UINT16 extends INT16
{

	public UINT16( short value )
	{
		super( value );
	}

}
