package org.sf.feeling.swt.win32.extension.jna.datatype;


public class UCHAR extends CHAR
{

	public UCHAR( byte value )
	{
		super( value );
	}

}
