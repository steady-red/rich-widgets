package org.sf.feeling.swt.win32.extension.jna.datatype;



public class ULONG extends LONG
{

	public ULONG( int value )
	{
		super( value );
	}

}
