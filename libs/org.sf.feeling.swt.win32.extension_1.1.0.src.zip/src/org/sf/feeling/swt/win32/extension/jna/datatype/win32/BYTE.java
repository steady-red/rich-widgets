package org.sf.feeling.swt.win32.extension.jna.datatype.win32;

import org.sf.feeling.swt.win32.extension.jna.datatype.CHAR;


public class BYTE extends CHAR
{

	public BYTE( byte value )
	{
		super( value );
	}

}
