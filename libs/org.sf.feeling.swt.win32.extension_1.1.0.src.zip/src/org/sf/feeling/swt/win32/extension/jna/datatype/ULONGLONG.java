package org.sf.feeling.swt.win32.extension.jna.datatype;


public class ULONGLONG extends LONGLONG
{

	public ULONGLONG( long value )
	{
		super( value );
	}

}
