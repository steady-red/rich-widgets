package org.sf.feeling.swt.win32.extension.jna.datatype.win32;

import org.sf.feeling.swt.win32.extension.jna.datatype.LONGLONG;


public class INT64 extends LONGLONG
{

	public INT64( long value )
	{
		super( value );
	}

}
