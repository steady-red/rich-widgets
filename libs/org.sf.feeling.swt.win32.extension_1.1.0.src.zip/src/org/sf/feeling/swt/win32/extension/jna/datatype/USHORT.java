package org.sf.feeling.swt.win32.extension.jna.datatype;


public class USHORT extends SHORT
{

	public USHORT( short value )
	{
		super( value );
	}

}
