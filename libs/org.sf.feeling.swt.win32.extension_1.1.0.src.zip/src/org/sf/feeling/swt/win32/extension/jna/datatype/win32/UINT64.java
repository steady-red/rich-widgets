package org.sf.feeling.swt.win32.extension.jna.datatype.win32;


public class UINT64 extends INT64
{

	public UINT64( long value )
	{
		super( value );
	}

}
