package org.sf.feeling.swt.win32.extension.jna.datatype.win32;

import org.sf.feeling.swt.win32.extension.jna.datatype.SHORT;


public class INT16 extends SHORT
{

	public INT16( short value )
	{
		super( value );
	}

}
