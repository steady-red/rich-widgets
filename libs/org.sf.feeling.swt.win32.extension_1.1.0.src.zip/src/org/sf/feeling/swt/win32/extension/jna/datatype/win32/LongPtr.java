package org.sf.feeling.swt.win32.extension.jna.datatype.win32;

import org.sf.feeling.swt.win32.extension.jna.datatype.LONG;

//32 bit.
public class LongPtr extends LONG
{

	public LongPtr( int value )
	{
		super( value );
	}

}
