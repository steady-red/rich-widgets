package org.sf.feeling.swt.win32.extension.jna.datatype.win32;


public class UINT8 extends INT8
{

	public UINT8( byte value )
	{
		super( value );
	}

}
