package org.sf.feeling.swt.win32.extension.jna.datatype.win32;

import org.sf.feeling.swt.win32.extension.jna.datatype.USHORT;


public class WORD extends USHORT
{

	public WORD( short value )
	{
		super( value );
	}

}
