package org.sf.feeling.swt.win32.extension.jna.datatype.win32;

import org.sf.feeling.swt.win32.extension.jna.datatype.LONG;

//32 bit.
public class IntPtr extends LONG
{

	public IntPtr( int value )
	{
		super( value );
	}

}
