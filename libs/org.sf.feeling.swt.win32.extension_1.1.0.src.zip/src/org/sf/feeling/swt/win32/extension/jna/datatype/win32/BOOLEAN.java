package org.sf.feeling.swt.win32.extension.jna.datatype.win32;

import org.sf.feeling.swt.win32.extension.jna.datatype.bool;


public class BOOLEAN extends bool
{

	public BOOLEAN( byte value )
	{
		super( value );
	}

}
