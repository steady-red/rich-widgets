package org.sf.feeling.swt.win32.extension.jna.datatype.win32;

import org.sf.feeling.swt.win32.extension.jna.datatype.CHAR;


public class INT8 extends CHAR
{

	public INT8( byte value )
	{
		super( value );
	}

}
