package org.sf.feeling.swt.win32.internal.extension;

public class MIXERHANDLE
{
	public int hMixer;
}
